using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using System.Collections.Generic;

// =========================================================================
// 1. PRESENTATION LAYER (Minimal APIs - Must be at the top)
// =========================================================================
var builder = WebApplication.CreateBuilder(args);

// Register the engines as Singletons
builder.Services.AddSingleton<OcsRuleEngine>();
builder.Services.AddSingleton<NavRuleEngine>();

var app = builder.Build();

app.MapPost("/api/ocs/evaluate", (PandaRequest<OcsInputs> request, OcsRuleEngine engine) =>
{
    var result = engine.Execute(request.Inputs, request.Trigger);
    return Results.Ok(result);
});

app.MapPost("/api/nav/evaluate", (PandaRequest<NavInputs> request, NavRuleEngine engine) =>
{
    var result = engine.Execute(request.Inputs, request.Trigger);
    return Results.Ok(result);
});

app.Run();

// =========================================================================
// 2. DOMAIN LAYER
// =========================================================================
public class FieldMetadata
{
    public bool IsReadOnly { get; set; }
    public string? Warning { get; set; }
}

public interface IPandaModule
{
    Dictionary<string, FieldMetadata> Metadata { get; set; }
    
    // UI DROPDOWN MAPPING: The explicit targets the user wants to solve for
    List<string> Intents { get; set; } 
    
    void ResetMetadata();
}

public interface IRule<T> where T : IPandaModule
{
    void Evaluate(T state, string triggerProperty);
}

public class PandaRequest<T> where T : IPandaModule
{
    public string Trigger { get; set; } = string.Empty;
    public T Inputs { get; set; } = default!;
}

// =========================================================================
// 3. APPLICATION LAYER (Zero-Allocation Engine)
// =========================================================================
public abstract class BaseRuleEngine<T> where T : class, IPandaModule
{
    protected readonly List<IRule<T>> Rules = new();

    public T Execute(T state, string triggerProperty)
    {
        state.ResetMetadata();

        foreach (var rule in Rules)
            rule.Evaluate(state, triggerProperty);

        return state;
    }
}

// =========================================================================
// 4. OCS MODULE
// =========================================================================
public class OcsInputs : IPandaModule
{
    public string Category { get; set; } = "CAT_I";
    public double Slope { get; set; } = 0.02;
    public double OffsetAngle { get; set; } = 15.0;
    public bool IsOffset { get; set; } = true;

    public Dictionary<string, FieldMetadata> Metadata { get; set; } = new();
    public List<string> Intents { get; set; } = new();

    public OcsInputs()
    {
        Metadata[nameof(Category)] = new FieldMetadata();
        Metadata[nameof(Slope)] = new FieldMetadata();
        Metadata[nameof(OffsetAngle)] = new FieldMetadata();
        Metadata[nameof(IsOffset)] = new FieldMetadata();
    }

    public void ResetMetadata()
    {
        foreach (var meta in Metadata.Values)
        {
            meta.IsReadOnly = false;
            meta.Warning = null;
        }
    }
}

public class OcsCategoryRule : IRule<OcsInputs>
{
    public void Evaluate(OcsInputs state, string trigger)
    {
        if (state.Category != "CAT_II") return;

        state.Slope = 0.025;
        state.Metadata[nameof(state.Slope)].IsReadOnly = true;
        state.Metadata[nameof(state.Slope)].Warning = "Regulatory fixed value for CAT II.";
    }
}

public class OcsRuleEngine : BaseRuleEngine<OcsInputs>
{
    public OcsRuleEngine() => Rules.Add(new OcsCategoryRule());
}

// =========================================================================
// 5. NAVIGATION MODULE (Intent Solver)
// =========================================================================
public class NavInputs : IPandaModule
{
    public double Distance { get; set; } = 1000;
    public double Gradient { get; set; } = 0.05;
    public double Altitude { get; set; } = 50;

    public Dictionary<string, FieldMetadata> Metadata { get; set; } = new();
    public List<string> Intents { get; set; } = new();

    public NavInputs()
    {
        Metadata[nameof(Distance)] = new FieldMetadata();
        Metadata[nameof(Gradient)] = new FieldMetadata();
        Metadata[nameof(Altitude)] = new FieldMetadata();
    }

    public void ResetMetadata()
    {
        foreach (var meta in Metadata.Values)
        {
            meta.IsReadOnly = false;
            meta.Warning = null;
        }
    }
}

public class TriangulationSolverRule : IRule<NavInputs>
{
    public void Evaluate(NavInputs state, string trigger)
    {
        if (trigger != nameof(state.Distance)) return;

        if (state.Distance == 0)
        {
            state.Metadata[nameof(state.Distance)].Warning = "Distance cannot be zero.";
            return;
        }

        // Check if the user selected "Gradient" in their UI dropdown
        bool solveGradient = state.Intents.Contains(nameof(state.Gradient));

        if (solveGradient)
        {
            state.Gradient = state.Altitude / state.Distance;
            state.Metadata[nameof(state.Gradient)].Warning = "Target recalculated based on user intent.";
        }
        else
        {
            // Default fallback if they selected Altitude, or left it blank
            state.Altitude = state.Distance * state.Gradient;
            state.Metadata[nameof(state.Altitude)].Warning = "Target recalculated based on user intent.";
        }
    }
}

public class NavRuleEngine : BaseRuleEngine<NavInputs>
{
    public NavRuleEngine() => Rules.Add(new TriangulationSolverRule());
}